R PROGRAMMING ASSIGNMENT 01
Name: Shravni Umrani
Roll No.: 23102C0058

Files:
1. Shravni_Umrani_23102C0058_R_Programming_Assignment_01.ipynb - ready notebook
2. Shravni_Umrani_R_Programming_Assignment_01.R - complete R script
3. Shravni_Umrani_R_Programming_Assignment_01.Rmd - R Markdown version

Important:
Upload PRSA_Data_Aotizhongxin_20130301-20170228.csv into the same working directory/session before running.
