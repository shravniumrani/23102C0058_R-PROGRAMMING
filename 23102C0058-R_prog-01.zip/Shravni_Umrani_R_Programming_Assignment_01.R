# R Programming Assignment 01
# Name: Shravni Umrani
# Roll No.: 23102C0058
# Experiment: Data Cleaning and Handling Missing Values

# Install/load packages
if (!require(ggplot2)) install.packages("ggplot2")
library(ggplot2)

# Task 1: Import dataset with error handling
file_name <- "PRSA_Data_Aotizhongxin_20130301-20170228.csv"

air_data <- tryCatch(
  {
    read.csv(file_name)
  },
  warning = function(w){
    message("Warning: ", w$message)
  },
  error = function(e){
    stop("Error: Unable to read the file.\nReason: ", e$message)
  },
  finally = {
    message("Import process completed.")
  }
)

cat("\nFirst Six Records\n")
head(air_data)

cat("\nStructure of Dataset\n")
str(air_data)

cat("\nRows :", nrow(air_data))
cat("\nColumns :", ncol(air_data))

cat("\nDoes dataset contain missing values?\n")
any(is.na(air_data))

cat("\nTotal Missing Values :", sum(is.na(air_data)), "\n")

# Save original data before cleaning
original_air_data <- air_data

# Task 2: Demonstrate NA, NULL, NaN and undefined/infinite values
temperature <- c(28, 30, NA, 32)
cat("\nTemperature Vector\n")
print(temperature)
cat("\nChecking NA Values\n")
print(is.na(temperature))

missing_object <- NULL
cat("\nChecking NULL Object\n")
print(is.null(missing_object))

undefined_value <- 0 / 0
cat("\nChecking NaN Value\n")
print(is.nan(undefined_value))

cat("\nNA Checks\n")
print(is.na(NA))
print(is.null(NA))
print(is.nan(NA))

cat("\nNULL Checks\n")
print(is.null(NULL))
print(is.na(NULL))
print(is.nan(NULL))

cat("\nNaN Checks\n")
print(is.na(NaN))
print(is.null(NaN))
print(is.nan(NaN))

# Task 3: Missing-value summary
selected_variables <- c("PM2.5", "PM10", "SO2", "NO2", "TEMP", "HSPM", "wd")

missing_summary <- function(data)
{
  summary_table <- data.frame(
    Variable = character(),
    Total_Records = integer(),
    Missing_Values = integer(),
    Missing_Percentage = numeric(),
    stringsAsFactors = FALSE
  )

  for(variable in selected_variables)
  {
    if(variable %in% names(data))
    {
      total_records <- nrow(data)
      missing_values <- sum(is.na(data[[variable]]))
      missing_percentage <- (missing_values / total_records) * 100

      summary_table <- rbind(
        summary_table,
        data.frame(
          Variable = variable,
          Total_Records = total_records,
          Missing_Values = missing_values,
          Missing_Percentage = round(missing_percentage, 2)
        )
      )

      if(missing_percentage > 20)
        warning(paste(variable, "contains more than 20% missing values."))
    }
    else
      warning(paste(variable, "does not exist in dataset."))
  }
  return(summary_table)
}

summary_result <- missing_summary(air_data)
cat("\nMissing Value Summary\n")
print(summary_result)

# Task 4: Handle NaN and Infinite values in pollution ratio
air_data$pollution_ratio <- air_data$PM2.5 / air_data$PM10

cat("\nPollution Ratio Summary\n")
cat("NA Values :", sum(is.na(air_data$pollution_ratio)), "\n")
cat("NaN Values :", sum(is.nan(air_data$pollution_ratio)), "\n")
cat("Positive Infinity :", sum(air_data$pollution_ratio == Inf, na.rm=TRUE), "\n")
cat("Negative Infinity :", sum(air_data$pollution_ratio == -Inf, na.rm=TRUE), "\n")
cat("Total Infinite Values :", sum(is.infinite(air_data$pollution_ratio)), "\n")

air_data$pollution_ratio[is.nan(air_data$pollution_ratio)] <- NA
air_data$pollution_ratio[is.infinite(air_data$pollution_ratio)] <- NA

cat("\nAfter Cleaning\n")
cat("NaN :", sum(is.nan(air_data$pollution_ratio)), "\n")
cat("Infinite :", sum(is.infinite(air_data$pollution_ratio)), "\n")
cat("NA :", sum(is.na(air_data$pollution_ratio)), "\n")

# Task 5: Handle missing numerical values using median
numeric_variables <- c("PM2.5", "PM10", "SO2", "NO2", "TEMP", "HSPM")

for(variable in numeric_variables)
{
  if(variable %in% names(air_data))
  {
    missing_before <- sum(is.na(air_data[[variable]]))
    median_value <- median(air_data[[variable]], na.rm = TRUE)
    air_data[[variable]][is.na(air_data[[variable]])] <- median_value
    missing_after <- sum(is.na(air_data[[variable]]))

    cat("\n------------------------------\n")
    cat("Variable :", variable, "\n")
    cat("Missing Before :", missing_before, "\n")
    cat("Median Used :", median_value, "\n")
    cat("Missing After :", missing_after, "\n")
  }
}

# Task 6: Handle missing categorical values using mode
calculate_mode <- function(x)
{
  x <- x[!is.na(x)]
  if(length(x) == 0) return(NA)
  frequency_table <- table(x)
  names(which.max(frequency_table))
}

if("wd" %in% names(air_data))
{
  missing_before <- sum(is.na(air_data$wd))
  mode_value <- calculate_mode(air_data$wd)
  air_data$wd[is.na(air_data$wd)] <- mode_value
  missing_after <- sum(is.na(air_data$wd))

  cat("\nWind Direction Cleaning\n")
  cat("Missing Before :", missing_before, "\n")
  cat("Mode Used :", mode_value, "\n")
  cat("Missing After :", missing_after, "\n")
}

# Task 7: Implement error handling
clean_variable <- function(data, variable_name)
{
  tryCatch({
    if(!(variable_name %in% names(data)))
      stop(paste("Variable", variable_name, "does not exist."))

    if(!is.numeric(data[[variable_name]]))
      stop(paste("Variable", variable_name, "is not numerical."))

    if(all(is.na(data[[variable_name]])))
      stop(paste("Variable", variable_name, "contains only missing values."))

    median_value <- median(data[[variable_name]], na.rm = TRUE)

    if(is.na(median_value))
      stop(paste("Median could not be calculated for", variable_name))

    missing_before <- sum(is.na(data[[variable_name]]))
    data[[variable_name]][is.na(data[[variable_name]])] <- median_value
    missing_after <- sum(is.na(data[[variable_name]]))

    cat("\n------------------------------\n")
    cat("Variable :", variable_name, "\n")
    cat("Missing Before :", missing_before, "\n")
    cat("Median Used :", median_value, "\n")
    cat("Missing After :", missing_after, "\n")
    cat(variable_name, "cleaned successfully.\n")
    return(data[[variable_name]])
  },
  error = function(e){
    message("Error: ", e$message)
    return(NULL)
  })
}

clean_pm25 <- clean_variable(air_data, "PM2.5")
clean_pm10 <- clean_variable(air_data, "PM10")
clean_temp <- clean_variable(air_data, "TEMP")
clean_variable(air_data, "ABC")
clean_variable(air_data, "wd")

# Task 8: Compare missing values before and after cleaning
comparison_variables <- c("PM2.5", "PM10", "SO2", "NO2", "TEMP", "HSPM", "wd")

comparison_table <- data.frame(
  Variable = character(),
  Missing_Before = integer(),
  Missing_After = integer(),
  Values_Replaced = integer(),
  stringsAsFactors = FALSE
)

for(variable in comparison_variables)
{
  if(variable %in% names(original_air_data))
  {
    before <- sum(is.na(original_air_data[[variable]]))
    after <- sum(is.na(air_data[[variable]]))
    replaced <- before - after

    comparison_table <- rbind(
      comparison_table,
      data.frame(
        Variable = variable,
        Missing_Before = before,
        Missing_After = after,
        Values_Replaced = replaced
      )
    )
  }
}

cat("\nComparison of Missing Values Before and After Cleaning\n")
print(comparison_table)

# Task 9: Visualization
plot_data <- data.frame(
  Variable = rep(comparison_table$Variable, 2),
  Missing_Values = c(comparison_table$Missing_Before,
                     comparison_table$Missing_After),
  Status = c(rep("Before Cleaning", nrow(comparison_table)),
             rep("After Cleaning", nrow(comparison_table)))
)

ggplot(plot_data, aes(x = Variable, y = Missing_Values, fill = Status)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(
    title = "Missing Values Before and After Data Cleaning",
    x = "Variables",
    y = "Number of Missing Values",
    fill = "Dataset"
  ) +
  theme_minimal()

# Task 10: Export cleaned dataset
tryCatch({
  write.csv(
    air_data,
    "cleaned_air_quality_dataset.csv",
    row.names = FALSE
  )
  cat("\n----------------------------------\n")
  cat("Cleaned dataset exported successfully.\n")
  cat("File Name : cleaned_air_quality_dataset.csv\n")
  cat("----------------------------------\n")
},
warning = function(w){
  message("Warning: ", w$message)
},
error = function(e){
  message("Error while exporting file: ", e$message)
},
finally = {
  cat("\nExport process completed.\n")
})
